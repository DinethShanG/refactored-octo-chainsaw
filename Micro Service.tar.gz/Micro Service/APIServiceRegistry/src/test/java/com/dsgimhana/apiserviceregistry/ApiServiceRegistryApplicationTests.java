package com.dsgimhana.apiserviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiServiceRegistryApplicationTests {

  @Test
  void contextLoads() {
  }

}
