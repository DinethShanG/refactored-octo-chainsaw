package com.dsgimhana.reservationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationServerApplicationTests {

  @Test
  void contextLoads() {
  }

}
