package com.dsgimhana.reservationserver.services;

import com.dsgimhana.reservationserver.exceptios.ResourceNotFoundException;
import com.dsgimhana.reservationserver.models.Reservation;
import com.dsgimhana.reservationserver.models.ReservationSlot;
import com.dsgimhana.reservationserver.models.TimeSlot;
import com.dsgimhana.reservationserver.payloads.requests.ReservationRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.List;

public interface ReservationService {
  List<Reservation> findAll();

  ResponseEntity<Reservation> findById(String id) throws ResourceNotFoundException;

  ResponseEntity <Reservation> save(String token, ReservationRequest reservationRequest);

  String deleteById(String id) throws ResourceNotFoundException;

  ResponseEntity<Reservation> update(String id, ReservationRequest reservationRequest) throws ResourceNotFoundException;





}
