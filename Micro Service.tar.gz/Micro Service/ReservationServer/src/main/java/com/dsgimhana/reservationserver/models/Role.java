package com.dsgimhana.reservationserver.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;

@Document(collection = "roles")
public class Role {

  @Id
  private String id;

  @NotNull
  private RoleType roleType;

  public Role() {
  }

  public Role(String id, RoleType roleType) {
    this.id = id;
    this.roleType = roleType;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public RoleType getRoleType() {
    return roleType;
  }

  public void setRoleType(RoleType roleType) {
    this.roleType = roleType;
  }
}
