package com.dsgimhana.reservationserver.payloads.requests;

public class ReservationRequest {
  private String reservationSlotId;
  private String vehicleNum;

  public ReservationRequest() {
  }

  public ReservationRequest(String reservationSlotId, String vehicleNum) {
    this.reservationSlotId = reservationSlotId;
    this.vehicleNum = vehicleNum;
  }

  public String getReservationSlotId() {
    return reservationSlotId;
  }

  public void setReservationSlotId(String reservationSlotId) {
    this.reservationSlotId = reservationSlotId;
  }

  public String getVehicleNum() {
    return vehicleNum;
  }

  public void setVehicleNum(String vehicleNum) {
    this.vehicleNum = vehicleNum;
  }
}
