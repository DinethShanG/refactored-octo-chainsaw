package com.dsgimhana.reservationserver.models;

public enum RoleType {
  ROLE_MANAGER,
  ROLE_CUSTOMER
}
