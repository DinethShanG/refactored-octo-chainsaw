package com.dsgimhana.reservationserver.services;

import com.dsgimhana.reservationserver.exceptios.ResourceNotFoundException;
import com.dsgimhana.reservationserver.models.Reservation;
import com.dsgimhana.reservationserver.models.ReservationSlot;
import com.dsgimhana.reservationserver.models.User;
import com.dsgimhana.reservationserver.payloads.requests.ReservationRequest;
import com.dsgimhana.reservationserver.repository.ReservationRepository;
import com.dsgimhana.reservationserver.security.jwt.AuthTokenFilter;
import com.dsgimhana.reservationserver.security.jwt.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class ReservationServiceImpl implements ReservationService{

  @Autowired
  private ReservationRepository reservationRepository;

  @Autowired
  private JwtUtils jwtUtils;

  @Autowired
  private AuthTokenFilter authTokenFilter;

  @Autowired
  private RestTemplate restTemplate;

  @Override
  public List<Reservation> findAll() {
    return reservationRepository.findAll();
  }

  @Override
  public ResponseEntity<Reservation> findById(String id) throws ResourceNotFoundException {
    Reservation reservation = reservationRepository.findById(id)
      .orElseThrow(() -> new ResourceNotFoundException("Reservation of id \" + id + \"not founded"));
    return ResponseEntity.ok().body(reservation);
  }


  @Override
  public ResponseEntity <Reservation> save(String token, ReservationRequest reservationRequest) {

    try{
      ReservationSlot reservationSlot = restTemplate.getForObject("http://management-service/managements/reserved/"+reservationRequest.getReservationSlotId(), ReservationSlot.class);
      System.out.println(reservationSlot);
    } catch (Exception e) {
      return new ResponseEntity("Reservation Slot of id; " + reservationRequest.getReservationSlotId() + " not founded", HttpStatus.NOT_FOUND);
    }

    Reservation newReservation = new Reservation();
    newReservation.setReservationSlotId(reservationRequest.getReservationSlotId());
    newReservation.setVehicleNum(reservationRequest.getVehicleNum());
    newReservation.setUserName(jwtUtils.getUserNameFromJwtToken(token.substring(7, token.length())));
    return ResponseEntity.ok(reservationRepository.save(newReservation));
  }

  @Override
  public String deleteById(String id) throws ResourceNotFoundException {
    Reservation reservation = reservationRepository.findById(id)
      .orElseThrow(() -> new ResourceNotFoundException("Reservation of id; " + id + " not founded"));

    reservationRepository.delete(reservation);
    return "deleted Reservation slot of id: "+id;
  }

  @Override
  public ResponseEntity<Reservation> update(String id, ReservationRequest reservationRequest) throws ResourceNotFoundException {
    Reservation currentReservation = reservationRepository.findById(id)
      .orElseThrow(() -> new ResourceNotFoundException("Reservation slot of id; " + id + " not founded"));
    currentReservation.setReservationSlotId(reservationRequest.getReservationSlotId());
    currentReservation.setVehicleNum(reservationRequest.getVehicleNum());

    return ResponseEntity.ok(reservationRepository.save(currentReservation));
  }
}
