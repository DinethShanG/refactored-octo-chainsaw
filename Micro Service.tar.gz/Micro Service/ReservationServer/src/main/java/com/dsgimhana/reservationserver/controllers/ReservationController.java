package com.dsgimhana.reservationserver.controllers;

import com.dsgimhana.reservationserver.models.Reservation;
import com.dsgimhana.reservationserver.payloads.requests.ReservationRequest;
import com.dsgimhana.reservationserver.services.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

  @Autowired
  private ReservationService reservationService;

  @GetMapping("/ping")
  public String ping() {
    return "Reservation Service pinged";
  }

  @GetMapping
  @PreAuthorize("hasRole('MANAGER')")
  public List<Reservation> getAllReservations() {
    return reservationService.findAll();
  }

  @PostMapping
  @PreAuthorize("hasRole('CUSTOMER')")
  public ResponseEntity<Reservation> createReservation(@RequestHeader(value = "Authorization") String token, @RequestBody ReservationRequest reservationRequest) {
    return reservationService.save(token, reservationRequest);
  }

}
