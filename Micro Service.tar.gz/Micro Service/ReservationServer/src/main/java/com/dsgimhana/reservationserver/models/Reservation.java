package com.dsgimhana.reservationserver.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "reservations")
public class Reservation {

  @Id
  private String id;
  private String reservationSlotId;
  private String vehicleNum;
  private String userName;

  public Reservation() {
  }

  public Reservation(String id, String reservationSlotId, String vehicleNum, String userName) {
    this.id = id;
    this.reservationSlotId = reservationSlotId;
    this.vehicleNum = vehicleNum;
    this.userName = userName;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getReservationSlotId() {
    return reservationSlotId;
  }

  public void setReservationSlotId(String reservationSlotId) {
    this.reservationSlotId = reservationSlotId;
  }

  public String getVehicleNum() {
    return vehicleNum;
  }

  public void setVehicleNum(String vehicleNum) {
    this.vehicleNum = vehicleNum;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }
}
