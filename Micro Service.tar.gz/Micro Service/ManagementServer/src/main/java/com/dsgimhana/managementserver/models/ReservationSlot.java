package com.dsgimhana.managementserver.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Document( collection = "reservationslots")
public class ReservationSlot {

  @Id
  private String id;

  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate date;

  private TimeSlot timeSlot;
  private int totalReservations;
  private int reservedReservations;
  private int remainingReservations;

  public ReservationSlot() {
  }

  public ReservationSlot(String id, LocalDate date, TimeSlot timeSlot, int totalReservations, int reservedReservations, int remainingReservations) {
    this.id = id;
    this.date = date;
    this.timeSlot = timeSlot;
    this.totalReservations = totalReservations;
    this.reservedReservations = reservedReservations;
    this.remainingReservations = remainingReservations;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public TimeSlot getTimeSlot() {
    return timeSlot;
  }

  public void setTimeSlot(TimeSlot timeSlot) {
    this.timeSlot = timeSlot;
  }

  public int getTotalReservations() {
    return totalReservations;
  }

  public void setTotalReservations(int totalReservations) {
    this.totalReservations = totalReservations;
  }

  public int getReservedReservations() {
    return reservedReservations;
  }

  public void setReservedReservations(int reservedReservations) {
    this.reservedReservations = reservedReservations;
  }

  public int getRemainingReservations() {
    return remainingReservations;
  }

  public void setRemainingReservations(int remainingReservations) {
    this.remainingReservations = remainingReservations;
  }
}
