package com.dsgimhana.managementserver.models;

public enum RoleType {
  ROLE_MANAGER,
  ROLE_CUSTOMER
}
