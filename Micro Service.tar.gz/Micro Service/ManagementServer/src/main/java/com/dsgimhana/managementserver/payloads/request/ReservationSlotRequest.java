package com.dsgimhana.managementserver.payloads.request;

import com.dsgimhana.managementserver.models.TimeSlot;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class ReservationSlotRequest {
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate date;

  private TimeSlot timeSlot;
  private int totalReservations;

  public ReservationSlotRequest() {
  }

  public ReservationSlotRequest(LocalDate date, TimeSlot timeSlot, int totalReservations) {
    this.date = date;
    this.timeSlot = timeSlot;
    this.totalReservations = totalReservations;
  }

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public TimeSlot getTimeSlot() {
    return timeSlot;
  }

  public void setTimeSlot(TimeSlot timeSlot) {
    this.timeSlot = timeSlot;
  }

  public int getTotalReservations() {
    return totalReservations;
  }

  public void setTotalReservations(int totalReservations) {
    this.totalReservations = totalReservations;
  }
}
