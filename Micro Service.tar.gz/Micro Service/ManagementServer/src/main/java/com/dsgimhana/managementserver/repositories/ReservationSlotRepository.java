package com.dsgimhana.managementserver.repositories;
import com.dsgimhana.managementserver.models.ReservationSlot;
import com.dsgimhana.managementserver.models.TimeSlot;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ReservationSlotRepository extends MongoRepository<ReservationSlot, String> {
  List <ReservationSlot> findByTimeSlot(TimeSlot timeSlot);
  ReservationSlot findByDateAndTimeSlot(LocalDate date, TimeSlot timeSlot);
  List<ReservationSlot> findAllByOrderByDateDesc();
  List<ReservationSlot> findByDate(LocalDate date);

}
