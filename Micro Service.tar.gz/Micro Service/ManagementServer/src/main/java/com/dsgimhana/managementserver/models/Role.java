package com.dsgimhana.managementserver.models;

public class Role {


  private String id;
  private RoleType roleType;

  public Role() {
  }

  public Role(String id, RoleType roleType) {
    this.id = id;
    this.roleType = roleType;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public RoleType getRoleType() {
    return roleType;
  }

  public void setRoleType(RoleType roleType) {
    this.roleType = roleType;
  }
}
