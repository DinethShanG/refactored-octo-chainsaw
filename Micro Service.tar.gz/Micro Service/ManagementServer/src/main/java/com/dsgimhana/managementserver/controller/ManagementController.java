package com.dsgimhana.managementserver.controller;

import com.dsgimhana.managementserver.exceptios.ResourceNotFoundException;
import com.dsgimhana.managementserver.models.ReservationSlot;
import com.dsgimhana.managementserver.payloads.request.ReservationSlotRequest;
import com.dsgimhana.managementserver.services.ReservationSlotServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/managements")
public class ManagementController {
  @Autowired
  private ReservationSlotServiceImpl reservationSlotService;

  @PostMapping("/slots")
  @PreAuthorize("hasRole('MANAGER')")
  public ReservationSlot createReservationSlot(@Valid @RequestBody ReservationSlotRequest reservationSlotRequest) {
    return reservationSlotService.save(reservationSlotRequest);
  }

  @GetMapping("/slots")
  @PreAuthorize("hasAnyRole('MANAGER', 'CUSTOMER')")
  public List<ReservationSlot> getAllReservationSlots() {
    return reservationSlotService.findAll();
  }

  @DeleteMapping("/slots/{id}")
  @PreAuthorize("hasRole('MANAGER')")
  public String deleteUser(@PathVariable(value = "id") String id) throws ResourceNotFoundException {
    return reservationSlotService.deleteById(id);
  }

  @PutMapping("/slots/{id}")
  @PreAuthorize("hasRole('MANAGER')")
  public ResponseEntity<ReservationSlot> update(@PathVariable(value = "id") String id,@Valid @RequestBody ReservationSlotRequest reservationSlotRequest) throws ResourceNotFoundException {
    return reservationSlotService.update(id, reservationSlotRequest);
  }

  @GetMapping("/slots/date/{date}")
  @PreAuthorize("hasAnyRole('MANAGER', 'CUSTOMER')")
  public List<ReservationSlot> findByDate(@PathVariable String date){
    LocalDate localDate = LocalDate.parse(date);
    return reservationSlotService.findByDate(localDate);
  }

  @GetMapping("/reserved/{id}")
  public ReservationSlot slotReserved(@PathVariable String id) throws ResourceNotFoundException {
      return reservationSlotService.slotReserved(id);
  }

  @GetMapping("/byId/{id}")
  public Optional<ReservationSlot> getReservationSlotById(@PathVariable String id) {
    return reservationSlotService.findById(id);
  }

}
