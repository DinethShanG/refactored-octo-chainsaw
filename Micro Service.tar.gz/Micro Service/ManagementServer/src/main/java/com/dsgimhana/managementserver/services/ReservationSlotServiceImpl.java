package com.dsgimhana.managementserver.services;

import com.dsgimhana.managementserver.exceptios.ResourceNotFoundException;
import com.dsgimhana.managementserver.models.ReservationSlot;
import com.dsgimhana.managementserver.models.TimeSlot;
import com.dsgimhana.managementserver.payloads.request.ReservationSlotRequest;
import com.dsgimhana.managementserver.repositories.ReservationSlotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationSlotServiceImpl implements ReservationSlotService{
  @Autowired
  ReservationSlotRepository reservationSlotRepository;

  @Override
  public List<ReservationSlot> findAll() {
    return reservationSlotRepository.findAll();
  }

  @Override
  public Optional<ReservationSlot> findById(String id) {
    return reservationSlotRepository.findById(id);
  }

  @Override
  public List<ReservationSlot> findByDate(LocalDate date) {
    return reservationSlotRepository.findByDate(date);
  }

  @Override
  public List<ReservationSlot> findByTimeSlot(TimeSlot timeSlot) {
    return reservationSlotRepository.findByTimeSlot(timeSlot);
  }

  @Override
  public ReservationSlot save(ReservationSlotRequest reservationSlotRequest) {
    ReservationSlot reservationSlot = new ReservationSlot();
    reservationSlot.setDate(reservationSlotRequest.getDate());
    reservationSlot.setTimeSlot(reservationSlotRequest.getTimeSlot());
    reservationSlot.setTotalReservations(reservationSlotRequest.getTotalReservations());
    reservationSlot.setReservedReservations(0);
    reservationSlot.setRemainingReservations(reservationSlotRequest.getTotalReservations());
    return reservationSlotRepository.save(reservationSlot);
  }

  @Override
  public String deleteById(String id) throws ResourceNotFoundException {
    ReservationSlot reservationSlot = reservationSlotRepository.findById(id)
      .orElseThrow(() -> new ResourceNotFoundException("Reservation slot of id; " + id + " not founded"));

    reservationSlotRepository.delete(reservationSlot);
    return "deleted Reservation slot of id: "+id;
  }

  @Override
  public ResponseEntity<ReservationSlot> update(String id, ReservationSlotRequest reservationSlotRequest) throws ResourceNotFoundException {
    ReservationSlot currentReservationSlot = reservationSlotRepository.findById(id)
    .orElseThrow(() -> new ResourceNotFoundException("Reservation slot of id; " + id + " not founded"));
    currentReservationSlot.setDate(reservationSlotRequest.getDate());
    currentReservationSlot.setTimeSlot(reservationSlotRequest.getTimeSlot());
    currentReservationSlot.setTotalReservations(reservationSlotRequest.getTotalReservations());
    currentReservationSlot.setRemainingReservations(currentReservationSlot.getTotalReservations() - currentReservationSlot.getReservedReservations());

    return ResponseEntity.ok(reservationSlotRepository.save(currentReservationSlot));
  }

  @Override
  public ReservationSlot slotReserved(String id) throws ResourceNotFoundException {
    ReservationSlot reservationSlot = reservationSlotRepository.findById(id)
      .orElseThrow(() -> new ResourceNotFoundException("Reservation slot of id; " + id + " not founded"));

    reservationSlot.setReservedReservations(reservationSlot.getReservedReservations()+ 1);
    reservationSlot.setRemainingReservations(reservationSlot.getTotalReservations() - reservationSlot.getReservedReservations());
    return reservationSlotRepository.save(reservationSlot);
  }


}
