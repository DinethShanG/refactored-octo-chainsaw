package com.dsgimhana.managementserver.services;

import com.dsgimhana.managementserver.exceptios.ResourceNotFoundException;
import com.dsgimhana.managementserver.models.ReservationSlot;
import com.dsgimhana.managementserver.models.TimeSlot;
import com.dsgimhana.managementserver.payloads.request.ReservationSlotRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ReservationSlotService {
  List<ReservationSlot> findAll();

  Optional<ReservationSlot> findById(String id) throws ResourceNotFoundException;

  List <ReservationSlot> findByDate(@DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date);

  List<ReservationSlot> findByTimeSlot(TimeSlot timeSlot);

  ReservationSlot save(ReservationSlotRequest reservationSlotRequest);

  String deleteById(String id) throws ResourceNotFoundException;

  ResponseEntity<ReservationSlot> update(String id, ReservationSlotRequest reservationSlotRequest) throws ResourceNotFoundException;

  ReservationSlot slotReserved(String id) throws ResourceNotFoundException;

}
