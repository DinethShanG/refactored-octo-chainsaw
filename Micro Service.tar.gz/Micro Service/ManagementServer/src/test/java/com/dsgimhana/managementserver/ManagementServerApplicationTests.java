package com.dsgimhana.managementserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementServerApplicationTests {

  @Test
  void contextLoads() {
  }

}
