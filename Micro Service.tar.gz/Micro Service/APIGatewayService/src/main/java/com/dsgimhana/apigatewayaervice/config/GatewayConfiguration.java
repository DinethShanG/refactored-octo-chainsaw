package com.dsgimhana.apigatewayaervice.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfiguration {
   @Bean
  public RouteLocator gatewayRoutesLocator(RouteLocatorBuilder routeLocatorBuilder) {
     return routeLocatorBuilder.routes()
       .route("reservation-service", r -> r.path("/reservations/**")
       .uri("http://localhost:8083/"))

       .route("management-service", r -> r.path("/managements/**")
         .uri("http://localhost:8082/"))

       .route("auth-service", r -> r.path("/auth/**")
         .uri("http://localhost:8084/"))

       .build();
   }
}
