package com.dsgimhana.authservice.models;

public enum RoleType {
  ROLE_MANAGER,
  ROLE_CUSTOMER
}
