package com.dsgimhana.authservice.controllers;

import com.dsgimhana.authservice.models.Role;
import com.dsgimhana.authservice.models.RoleType;
import com.dsgimhana.authservice.models.User;
import com.dsgimhana.authservice.payload.request.SigninRequest;
import com.dsgimhana.authservice.payload.request.SignupRequest;
import com.dsgimhana.authservice.payload.respond.JwtResponse;
import com.dsgimhana.authservice.payload.respond.MessageResponse;
import com.dsgimhana.authservice.repository.RoleRepository;
import com.dsgimhana.authservice.repository.UserRepository;
import com.dsgimhana.authservice.security.jwt.JwtUtils;
import com.dsgimhana.authservice.security.services.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/auth")
public class AuthController {
  @Autowired
  AuthenticationManager authenticationManager;

  @Autowired
  UserRepository userRepository;

  @Autowired
  RoleRepository roleRepository;

  @Autowired
  PasswordEncoder encoder;

  @Autowired
  JwtUtils jwtUtils;

  @PostMapping("/signin")
  public ResponseEntity<?> authenticateUser(@Valid @RequestBody SigninRequest signinRequest) {

    Authentication authentication = authenticationManager.authenticate(
      new UsernamePasswordAuthenticationToken(signinRequest.getUsername(), signinRequest.getPassword()));

    SecurityContextHolder.getContext().setAuthentication(authentication);
    String jwt = jwtUtils.generateJwtToken(authentication);

    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
    List<String> roles = userDetails.getAuthorities().stream()
      .map(item -> item.getAuthority())
      .collect(Collectors.toList());

    return ResponseEntity.ok(new JwtResponse(jwt,
      userDetails.getId(),
      userDetails.getUsername(),
      roles));
  }

  @PostMapping("/signup")
  public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
    if (userRepository.existsByUsername(signUpRequest.getUsername())) {
      return ResponseEntity
        .badRequest()
        .body(new MessageResponse("Error: Username is already taken!"));
    }


    // Create new user's account
    User user = new User(signUpRequest.getUsername(),
      encoder.encode(signUpRequest.getPassword()));

    List<String> strRoles = signUpRequest.getRoles();
    List<Role> roles = new ArrayList<>();

    if (strRoles == null) {
      Role userRole = roleRepository.findByRoleType(RoleType.ROLE_CUSTOMER)
        .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
      roles.add(userRole);
    } else {
      strRoles.forEach(role -> {
        switch (role.toLowerCase()) {
          case "manager":
            Role managerRole = roleRepository.findByRoleType(RoleType.ROLE_MANAGER)
              .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            roles.add(managerRole);
            break;
          default:
            Role customerRole = roleRepository.findByRoleType(RoleType.ROLE_CUSTOMER)
              .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            roles.add(customerRole);
        }
      });
    }

    user.setRoles(roles);
    userRepository.save(user);

    return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
  }

  @RequestMapping("username/{username}")
  public User findUserByUsername(@PathVariable("username") String username) {
    User user = userRepository.findByUsername(username)
      .orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + username));
    return user;
  }
}
