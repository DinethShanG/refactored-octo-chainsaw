package com.dsgimhana.authservice.payload.request;

import javax.validation.constraints.NotBlank;
import java.util.List;

public class SignupRequest {

  @NotBlank
  private String username;


  private List<String> roles;

  @NotBlank
  private String password;


  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public List<String> getRoles() {
    return this.roles;
  }

  public void setRole(List<String> roles) {
    this.roles = roles;
  }

}
